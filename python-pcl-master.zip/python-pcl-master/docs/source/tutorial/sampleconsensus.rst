Sampleconsensus Tutorials
=========================


How to use Random Sample Consensus model
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
In this tutorial we learn how to use a RandomSampleConsensus with a plane model to obtain the cloud fitting to this model.

* `Original <http://pointclouds.org/documentation/tutorials/random_sample_consensus.php#random-sample-consensus>`_ \
* TestCode : examples/official/SampleConsensus/random_sample_consensus.py


